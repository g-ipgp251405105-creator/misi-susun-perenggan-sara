import { getStore } from '@netlify/blobs';
import { createHash } from 'node:crypto';

const storeName='sara-susun-ranking-v1';
function reply(data,status=200){return new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}})}
function clean(s){return String(s??'').trim().replace(/\s+/g,' ').slice(0,40)}
function validName(s){return /^[\p{L}\p{N} ._'-]{1,40}$/u.test(s) && !/^[=+@-]/.test(s)}
async function scores(){const store=getStore(storeName);const all=[];let cursor;for(let page=0;page<10;page++){const out=await store.list({prefix:'murid-',...(cursor?{cursor}:{})});for(const entry of out.blobs||[]){const r=await store.get(entry.key,{type:'json'});if(r&&validName(r.name)&&Number.isInteger(r.score)&&r.score>=0&&r.score<=6&&Number.isInteger(r.mistakes))all.push(r)}cursor=out.cursor;if(!cursor)break}all.sort((a,b)=>b.score-a.score||a.mistakes-b.mistakes||a.name.localeCompare(b.name,'ms'));return all.slice(0,40)}
export default async (request)=>{
 try{
  if(request.method==='GET')return reply({ok:true,rows:await scores()});
  if(request.method!=='POST')return reply({ok:false,error:'Kaedah tidak disokong'},405);
  const len=Number(request.headers.get('content-length')||0);if(len>1200)return reply({ok:false,error:'Permintaan terlalu panjang'},413);
  let body;try{body=await request.json()}catch{return reply({ok:false,error:'Data bukan JSON sah'},400)}
  const name=clean(body.name),score=Number(body.score),mistakes=Number(body.mistakes);
  if(!validName(name)||score!==6||!Number.isInteger(mistakes)||mistakes<0||mistakes>10000)return reply({ok:false,error:'Nama samaran atau markah tidak sah'},400);
  const key='murid-'+createHash('sha256').update(name.toLocaleLowerCase('ms')).digest('hex');
  const store=getStore(storeName);const prev=await store.get(key,{type:'json'});
  // Kekalkan pencapaian terbaik bagi nama samaran sama: 6/6 dan kesilapan paling sedikit.
  if(!prev || prev.score<score || (prev.score===score&&prev.mistakes>mistakes))await store.setJSON(key,{name,score,mistakes,when:new Date().toISOString()});
  return reply({ok:true});
 }catch(error){console.error(error);return reply({ok:false,error:'Gagal menyambung ke simpanan Netlify'},500)}
};
export const config={path:'/api/scores'};
